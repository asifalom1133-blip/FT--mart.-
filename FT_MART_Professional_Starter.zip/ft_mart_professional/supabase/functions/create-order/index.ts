import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } });
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
  try {
    const authHeader = req.headers.get('Authorization') || '';
    const token = authHeader.replace(/^Bearer\s+/i, '');
    if (!token) return json({ error: 'Sign in required' }, 401);
    const url = Deno.env.get('SUPABASE_URL')!;
    const publishableKeys = Deno.env.get('SUPABASE_PUBLISHABLE_KEYS');
    const anon = Deno.env.get('SUPABASE_ANON_KEY') || Deno.env.get('SUPABASE_PUBLISHABLE_KEY') || (publishableKeys ? JSON.parse(publishableKeys).default : undefined);
    const secretKeys = Deno.env.get('SUPABASE_SECRET_KEYS');
    const service = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || (secretKeys ? JSON.parse(secretKeys).default : undefined);
    if (!anon || !service) return json({ error: 'Supabase server keys are not configured' }, 503);
    const userClient = createClient(url, anon, { global: { headers: { Authorization: `Bearer ${token}` } } });
    const { data: { user }, error: authError } = await userClient.auth.getUser(token);
    if (authError || !user) return json({ error: 'Invalid session' }, 401);
    const admin = createClient(url, service);
    const body = await req.json();
    const { items, customer_name, phone, address, payment_method } = body;
    if (!Array.isArray(items) || items.length < 1 || items.length > 30) return json({ error: 'Invalid cart' }, 400);
    if (!customer_name?.trim() || !phone?.trim() || !address?.trim()) return json({ error: 'Name, phone and address are required' }, 400);
    if (!['razorpay', 'cod'].includes(payment_method)) return json({ error: 'Invalid payment method' }, 400);
    const quantities = new Map<string, number>();
    for (const item of items) {
      if (!item.product_id || !Number.isInteger(item.quantity) || item.quantity < 1 || item.quantity > 20) return json({ error: 'Invalid cart item' }, 400);
      quantities.set(item.product_id, (quantities.get(item.product_id) || 0) + item.quantity);
    }
    const ids = [...quantities.keys()];
    const { data: products, error: productsError } = await admin.from('products').select('id,name,price,is_active,stock_quantity').in('id', ids);
    if (productsError || !products || products.length !== ids.length) return json({ error: 'One or more products are unavailable' }, 400);
    const rows = [];
    let subtotal = 0;
    for (const p of products) {
      if (!p.is_active) return json({ error: `${p.name} is unavailable` }, 400);
      const quantity = quantities.get(p.id)!;
      if (p.stock_quantity !== null && quantity > p.stock_quantity) return json({ error: `Only ${p.stock_quantity} units of ${p.name} are available` }, 400);
      const unit = Number(p.price);
      subtotal += unit * quantity;
      rows.push({ product_id: p.id, product_name: p.name, unit_price: unit, quantity, line_total: unit * quantity });
    }
    const shipping = 0;
    const total = subtotal + shipping;
    if (total <= 0) return json({ error: 'Invalid order total' }, 400);
    let razorpayOrderId: string | null = null;
    if (payment_method === 'razorpay') {
      const keyId = Deno.env.get('RAZORPAY_KEY_ID');
      const keySecret = Deno.env.get('RAZORPAY_KEY_SECRET');
      if (!keyId || !keySecret) return json({ error: 'Online payment is not configured yet' }, 503);
      const auth = btoa(`${keyId}:${keySecret}`);
      const rp = await fetch('https://api.razorpay.com/v1/orders', { method: 'POST', headers: { Authorization: `Basic ${auth}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ amount: Math.round(total * 100), currency: 'INR', receipt: `ftmart_${crypto.randomUUID().slice(0, 24)}` }) });
      const rpData = await rp.json();
      if (!rp.ok) return json({ error: rpData.error?.description || 'Could not create payment order' }, 502);
      razorpayOrderId = rpData.id;
    }
    const orderNumber = `FTM-${Date.now().toString().slice(-9)}`;
    const { data: order, error: orderError } = await admin.from('orders').insert({ order_number: orderNumber, user_id: user.id, customer_name: customer_name.trim(), phone: phone.trim(), address: address.trim(), payment_method, payment_status: 'pending', status: payment_method === 'cod' ? 'confirmed' : 'pending', subtotal, shipping_amount: shipping, total_amount: total, razorpay_order_id: razorpayOrderId }).select().single();
    if (orderError || !order) return json({ error: orderError?.message || 'Could not save order' }, 500);
    const { error: itemsError } = await admin.from('order_items').insert(rows.map(r => ({ ...r, order_id: order.id })));
    if (itemsError) { await admin.from('orders').delete().eq('id', order.id); return json({ error: 'Could not save order items' }, 500); }
    const { error: stockError } = await admin.rpc('reserve_product_stock', { p_items: rows.map(r => ({ product_id: r.product_id, quantity: r.quantity })) });
    if (stockError) { await admin.from('orders').delete().eq('id', order.id); return json({ error: stockError.message || 'Insufficient stock' }, 409); }
    await admin.from('orders').update({ stock_deducted: true }).eq('id', order.id);
    if (payment_method === 'cod') return json({ order_id: order.id, order_number: order.order_number, payment_method: 'cod', total_amount: total });
    return json({ order_id: order.id, order_number: order.order_number, razorpay_order_id: razorpayOrderId, amount: Math.round(total * 100), currency: 'INR', key_id: Deno.env.get('RAZORPAY_KEY_ID') });
  } catch (error) { console.error(error); return json({ error: 'Unexpected server error' }, 500); }
});
