import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });
const toHex = (buffer: ArrayBuffer) => [...new Uint8Array(buffer)].map(b => b.toString(16).padStart(2, '0')).join('');
function safeEqual(a: string, b: string) { if (a.length !== b.length) return false; let diff = 0; for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i); return diff === 0; }
Deno.serve(async (req) => {
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
  try {
    const raw = await req.text();
    const signature = req.headers.get('x-razorpay-signature') || '';
    const secret = Deno.env.get('RAZORPAY_WEBHOOK_SECRET');
    if (!secret || !signature) return json({ error: 'Webhook is not configured' }, 400);
    const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
    const expected = toHex(await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(raw)));
    if (!safeEqual(expected, signature)) return json({ error: 'Invalid webhook signature' }, 400);
    const event = JSON.parse(raw);
    const secretKeys = Deno.env.get('SUPABASE_SECRET_KEYS');
    const service = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || (secretKeys ? JSON.parse(secretKeys).default : undefined);
    if (!service) return json({ error: 'Supabase server key is not configured' }, 503);
    const admin = createClient(Deno.env.get('SUPABASE_URL')!, service);
    if (event.event === 'payment.captured' || event.event === 'order.paid') {
      const payment = event.payload?.payment?.entity;
      const razorpayOrderId = payment?.order_id || event.payload?.order?.entity?.id;
      if (razorpayOrderId) await admin.from('orders').update({ payment_status: 'paid', status: 'confirmed', razorpay_payment_id: payment?.id || null }).eq('razorpay_order_id', razorpayOrderId);
    } else if (event.event === 'payment.failed') {
      const payment = event.payload?.payment?.entity;
      if (payment?.order_id) { const { data: order } = await admin.from('orders').select('id,payment_status').eq('razorpay_order_id', payment.order_id).maybeSingle(); if (order?.payment_status === 'pending') { await admin.rpc('restore_order_stock', { p_order_id: order.id }); await admin.from('orders').update({ payment_status: 'failed' }).eq('id', order.id).eq('payment_status', 'pending'); } }
    }
    return json({ received: true });
  } catch (error) { console.error(error); return json({ error: 'Webhook processing failed' }, 500); }
});
