-- FT MART database schema for Supabase (PostgreSQL)
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null default 'General',
  description text,
  price numeric(12,2) not null check (price >= 0),
  compare_at_price numeric(12,2) check (compare_at_price is null or compare_at_price >= 0),
  emoji text default '✨',
  image_url text,
  stock_quantity integer default null check (stock_quantity is null or stock_quantity >= 0),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique,
  user_id uuid not null references auth.users(id),
  customer_name text not null,
  phone text not null,
  address text not null,
  payment_method text not null check (payment_method in ('razorpay','cod')),
  payment_status text not null default 'pending' check (payment_status in ('pending','paid','failed','refunded')),
  status text not null default 'pending' check (status in ('pending','confirmed','packed','shipped','delivered','cancelled')),
  subtotal numeric(12,2) not null check (subtotal >= 0),
  shipping_amount numeric(12,2) not null default 0 check (shipping_amount >= 0),
  total_amount numeric(12,2) not null check (total_amount >= 0),
  razorpay_order_id text unique,
  razorpay_payment_id text,
  stock_deducted boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  unit_price numeric(12,2) not null check (unit_price >= 0),
  quantity integer not null check (quantity > 0),
  line_total numeric(12,2) not null check (line_total >= 0)
);

create table if not exists public.wishlists (
  user_id uuid not null references auth.users(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id, product_id)
);

create index if not exists products_active_category_idx on public.products(is_active, category);
create index if not exists orders_user_created_idx on public.orders(user_id, created_at desc);
create index if not exists order_items_order_idx on public.order_items(order_id);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id, full_name) values (new.id, new.raw_user_meta_data->>'full_name')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$ begin new.updated_at = now(); return new; end; $$;
drop trigger if exists products_updated_at on public.products;
create trigger products_updated_at before update on public.products for each row execute procedure public.set_updated_at();
drop trigger if exists orders_updated_at on public.orders;
create trigger orders_updated_at before update on public.orders for each row execute procedure public.set_updated_at();


create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

-- Inventory helpers. NULL stock_quantity means inventory is not tracked; 0 means sold out.
create or replace function public.reserve_product_stock(p_items jsonb)
returns void language plpgsql security definer set search_path = public as $$
declare item jsonb; pid uuid; qty integer; current_stock integer;
begin
  for item in select * from jsonb_array_elements(p_items) loop
    pid := (item->>'product_id')::uuid; qty := (item->>'quantity')::integer;
    select stock_quantity into current_stock from public.products where id = pid for update;
    if not found then raise exception 'Product not found'; end if;
    if current_stock is not null then
      if current_stock < qty then raise exception 'Insufficient stock for product %', pid; end if;
      update public.products set stock_quantity = stock_quantity - qty where id = pid;
    end if;
  end loop;
end;
$$;

create or replace function public.restore_order_stock(p_order_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare item record;
begin
  if not exists(select 1 from public.orders where id = p_order_id and stock_deducted = true) then return; end if;
  for item in select product_id, quantity from public.order_items where order_id = p_order_id and product_id is not null loop
    update public.products set stock_quantity = stock_quantity + item.quantity where id = item.product_id and stock_quantity is not null;
  end loop;
  update public.orders set stock_deducted = false where id = p_order_id;
end;
$$;
revoke all on function public.reserve_product_stock(jsonb) from public, anon, authenticated;
grant execute on function public.reserve_product_stock(jsonb) to service_role;
revoke all on function public.restore_order_stock(uuid) from public, anon, authenticated;
grant execute on function public.restore_order_stock(uuid) to service_role;

create or replace function public.restore_stock_on_cancel()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'cancelled' and old.status is distinct from new.status and new.stock_deducted then
    perform public.restore_order_stock(new.id);
  end if;
  return new;
end;
$$;
drop trigger if exists orders_restore_stock_on_cancel on public.orders;
create trigger orders_restore_stock_on_cancel after update of status on public.orders
for each row execute procedure public.restore_stock_on_cancel();

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.wishlists enable row level security;

-- Profiles: customers can read their own profile; admins can read all. A customer cannot promote themselves.
create policy "profile read own or admin" on public.profiles for select to authenticated
using (id = auth.uid() or public.is_admin());
create policy "profile update own customer fields" on public.profiles for update to authenticated
using (id = auth.uid()) with check (id = auth.uid() and role = 'customer');

-- Storefront can read active products. Admins can manage the catalogue.
create policy "public read active products" on public.products for select to anon, authenticated using (is_active = true or public.is_admin());
create policy "admin insert products" on public.products for insert to authenticated
with check (public.is_admin());
create policy "admin update products" on public.products for update to authenticated
using (public.is_admin())
with check (public.is_admin());
create policy "admin delete products" on public.products for delete to authenticated
using (public.is_admin());

-- Orders and order items are created by the trusted Edge Functions (service role). Customers read only their own.
create policy "read own orders or admin" on public.orders for select to authenticated
using (user_id = auth.uid() or public.is_admin());
create policy "admin update orders" on public.orders for update to authenticated
using (public.is_admin())
with check (public.is_admin());
create policy "read own order items or admin" on public.order_items for select to authenticated
using (exists(select 1 from public.orders o where o.id = order_id and (o.user_id = auth.uid() or public.is_admin())));

create policy "read own wishlist" on public.wishlists for select to authenticated using (user_id = auth.uid());
create policy "add own wishlist" on public.wishlists for insert to authenticated with check (user_id = auth.uid());
create policy "remove own wishlist" on public.wishlists for delete to authenticated using (user_id = auth.uid());

-- IMPORTANT: after creating your account, promote your own profile to admin from the SQL editor:
-- update public.profiles set role = 'admin' where id = (select id from auth.users where email = 'YOUR_ADMIN_EMAIL');
