// Public browser configuration only. Never put Razorpay secret or Supabase service-role keys here.
window.FTMART_CONFIG = {
  SUPABASE_URL: "https://YOUR-PROJECT.supabase.co",
  SUPABASE_ANON_KEY: "YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY",
  RAZORPAY_KEY_ID: "rzp_test_REPLACE_ME"
};
