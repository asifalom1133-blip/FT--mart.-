FT MART — Professional Shopping App Starter
===========================================

আপনার পুরোনো FT MART স্টার্টার ওয়েবসাইটকে English-language responsive shopping app হিসেবে নতুনভাবে সাজানো হয়েছে। এতে আছে:
- Mobile-first storefront, product search এবং category filter
- Product cards, cart, wishlist
- Customer email/password sign-up ও sign-in (Supabase সংযোগের পরে)
- Customer order history/status
- Admin dashboard: product add/edit/hide, stock quantity, order status update
- Razorpay Checkout + server-side signature/payment verification
- Cash on Delivery (COD)
- Supabase database schema, Row Level Security policies এবং Edge Functions
- PWA manifest/service worker: HTTPS-এ Android Chrome থেকে install করা যায়

গুরুত্বপূর্ণ: এটি একটি প্রস্তুত starter project, এখনো আপনার Supabase/Razorpay account-এ deploy বা configure করা হয়নি। কোনো বাস্তব payment বা order এখনো গ্রহণ করছে না। Production-এ চালানোর আগে নিচের setup সম্পূর্ণ করতে হবে।

A. Supabase backend তৈরি
-----------------------
1. https://supabase.com এ গিয়ে একটি নতুন project তৈরি করুন। Project database password নিরাপদে রাখুন।
2. Supabase Dashboard → SQL Editor খুলুন। এই ZIP-এর supabase/schema.sql ফাইলের সম্পূর্ণ SQL paste করে Run করুন।
3. Authentication → Providers-এ Email provider চালু রাখুন। Site URL এবং redirect URL-এ পরে আপনার Netlify URL বসাবেন।
4. আপনার অ্যাপের config.js ফাইলে SUPABASE_URL এবং SUPABASE_ANON_KEY-এর জায়গায় Supabase Project URL এবং Publishable/anon key বসান। এই public key ব্রাউজারে ব্যবহার করা যায়, কারণ database-এ RLS policy আছে। Secret/service-role key কখনো config.js বা browser code-এ দেবেন না।

B. Admin account তৈরি
---------------------
1. ওয়েব অ্যাপে নিজের admin email দিয়ে একটি account sign up করুন। Email confirmation চালু থাকলে email confirm করুন।
2. Supabase → SQL Editor-এ নিচের query চালান (নিজের email বসান):
   update public.profiles
   set role = 'admin'
   where id = (select id from auth.users where email = 'YOUR_ADMIN_EMAIL');
3. Sign out করে আবার sign in করুন। Header-এ Admin বাটন দেখা যাবে।
4. Admin Dashboard → Products থেকে নিজের আসল পণ্য, দাম, ছবি URL এবং stock quantity যোগ করুন। Stock quantity ফাঁকা রাখলে inventory tracking হবে না; 0 দিলে পণ্যটি stock-out হিসেবে গণ্য হবে।

C. Razorpay server-side setup
-----------------------------
1. প্রথমে Razorpay Dashboard-এর Test Mode ব্যবহার করুন। Live Mode পরে চালু করবেন।
2. Supabase CLI ইনস্টল করে project link করুন:
   supabase login
   supabase link --project-ref YOUR_PROJECT_REF
3. Edge Functions deploy করুন:
   supabase functions deploy create-order
   supabase functions deploy verify-payment
   supabase functions deploy razorpay-webhook
4. Supabase Edge Functions → Secrets-এ এই secret values দিন:
   RAZORPAY_KEY_ID=rzp_test_...
   RAZORPAY_KEY_SECRET=আপনার Razorpay Test Secret
   RAZORPAY_WEBHOOK_SECRET=আপনার তৈরি webhook secret
   SUPABASE_SERVICE_ROLE_KEY=পুরোনো service_role key (অথবা project-এর supported secret key environment variable)
   SUPABASE_ANON_KEY=পুরোনো anon key (অথবা publishable key environment variable)
   নতুন Supabase key format ব্যবহার করলে Edge Functions runtime-এ SUPABASE_PUBLISHABLE_KEYS এবং SUPABASE_SECRET_KEYS স্বয়ংক্রিয়ভাবে পাওয়া যেতে পারে।
5. Razorpay Dashboard → Webhooks-এ webhook URL দিন:
   https://YOUR_PROJECT_REF.supabase.co/functions/v1/razorpay-webhook
   Event হিসেবে payment.captured, payment.failed এবং order.paid নির্বাচন করুন। Webhook secret-টি Supabase secret-এর সঙ্গে হুবহু মিলতে হবে।
6. config.js-এ RAZORPAY_KEY_ID-তে শুধু Public Key ID দিন। Secret Key কখনো config.js-এ দেবেন না।
7. Razorpay Test Mode-এ test payment দিয়ে যাচাই করুন। সফল payment server-এ signature, order ID, amount, currency এবং captured status মিলিয়ে যাচাই হয়। Webhook-ও payment status sync করে।

D. Free hosting ও install
-------------------------
1. Netlify-তে free account খুলুন: https://www.netlify.com
2. এই project folder-এর সব ফাইল Netlify-তে deploy করুন। Netlify একটি HTTPS subdomain দেবে (যেমন your-store.netlify.app); শুরুতে custom domain কেনার দরকার নেই।
3. Supabase Authentication → URL Configuration-এ Netlify URL-টি Site URL এবং Redirect URL হিসেবে যোগ করুন।
4. Android Chrome-এ live HTTPS website খুলুন → Browser menu → Install app / Add to Home Screen। iPhone Safari-তে Share → Add to Home Screen।

E. নিরাপত্তা ও সীমাবদ্ধতা
-----------------------
- Razorpay secret, Supabase service-role/secret key কখনো frontend-এ রাখবেন না। শুধু Supabase Edge Function Secrets-এ রাখুন।
- Order amount browser থেকে বিশ্বাস করা হয় না; server database-এর product price থেকে total হিসাব করে।
- Stock quantity থাকলে order create করার সময় atomicভাবে stock reserve/deduct হয়। COD order cancel করলে এবং Razorpay payment failed webhook এলে stock ফেরত দেওয়া হয়।
- Admin access profile role + database RLS policy দিয়ে নিয়ন্ত্রিত। Admin role শুধু Supabase SQL Editor থেকে নির্ধারণ করুন।
- Wishlist আপাতত ওই browser/device-এর local storage-এ থাকে; user account-এর মধ্যে sync করা হয়নি।
- Product image এখন URL দিয়ে যোগ করতে হয়; built-in image upload screen নেই।
- Email OTP/SMS OTP, delivery partner API, GST invoice, refunds, coupons, analytics এবং automated email/SMS এখনো যুক্ত হয়নি।
- এই package হলো installable PWA; এটি এখনো native Android APK নয়। Native APK বানাতে পরবর্তী ধাপে Android wrapper/Capacitor build, app signing এবং release testing লাগবে।
- Live ব্যবসার আগে privacy policy, terms, shipping/return policy, customer support details, tax/invoice requirements এবং Razorpay account approval সম্পূর্ণ করুন।

কোনো credentials চ্যাটে পাঠাবেন না। Setup-এর সময় dashboard-এ নিজে secret বসাবেন।
